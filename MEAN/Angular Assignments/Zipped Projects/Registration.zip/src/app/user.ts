export class User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  address: string;
  unit: string;
  city: string;
  state: string;
  lucky: boolean;
}

