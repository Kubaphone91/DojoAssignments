import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-super-saiyan-three',
  templateUrl: './super-saiyan-three.component.html',
  styleUrls: ['./super-saiyan-three.component.css']
})
export class SuperSaiyanTHreeComponent implements OnInit {

  @Input() super_saiyan_three_power;

  constructor() { }

  ngOnInit() {
  }

}
