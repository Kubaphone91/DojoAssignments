var mathlib = require('./mathlib')();
console.log(mathlib);

mathlib.add(4,5);
mathlib.multiply(3,5);
mathlib.square(5);
mathlib.random(9,10);
