export class Note{
  note: string;
}
